from flask import Flask, request, jsonify
from flask_cors import CORS  # Add this import
import requests

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

OLLAMA_URL = "http://localhost:11434/api/generate"

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_message = data.get("message", "")
    if not user_message:
        return jsonify({"response": "Please enter a message."})

    try:
        payload = {
            "model": "llama2",
            "prompt": user_message,
            "stream": False
        }
        response = requests.post(OLLAMA_URL, json=payload)
        response.raise_for_status()
        bot_response = response.json().get("response", "").strip()

        return jsonify({"response": bot_response})
    
    except Exception as e:
        return jsonify({"response": f"Error: {str(e)}"})

if __name__ == "__main__":
    app.run(debug=True)
